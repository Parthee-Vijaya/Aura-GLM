<!-- ai-harness:start -->
AI Harness' fælles grundregler og oversigten over skills står i AGENTS.md:

@AGENTS.md
<!-- ai-harness:slut -->
