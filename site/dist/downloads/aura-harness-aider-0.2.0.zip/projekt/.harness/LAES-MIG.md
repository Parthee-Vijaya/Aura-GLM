# Aura Harness i dette projekt

Projektet bruger Aura Harness 0.2.0 til Aider. Aura Harness giver kodeagenten fælles grundregler og 12 af 12 skills til arbejdet fra idé til drift.

- Grundreglerne står i et afgrænset afsnit i AGENTS.md.
- Skillsene ligger i `.agents/skills/`.
- `installation.json` registrerer version og kontrolsummer, så en opdatering eller fjernelse kun rører uændrede filer.

Skriv projektets egne regler uden for Aura Harness-afsnittet. Hvis du ændrer en installeret skill, bevarer Aura Harness din ændring og springer filen over ved opdatering.

## Skills

- **Idé og afgrænsning** (`harness-ide-og-afgraensning`): Afklarer brugere, vigtigste handling, data og acceptkriterier, før der bygges.
- **Eksisterende projekt** (`harness-eksisterende-projekt`): Læser et eksisterende projekt, før der foreslås ændringer, og bevarer dets konventioner.
- **Arkitektur og teknologi** (`harness-arkitektur-og-teknologi`): Anbefaler én begrundet løsning til platform, framework, data, login og hosting med alternativer og konsekvenser.
- **Data og leverandører** (`harness-data-og-leverandoerer`): Fører en dataoversigt over dataforløb, leverandører og åbne spørgsmål og peger på de rette fagpersoner.
- **Nøgler og afhængigheder** (`harness-noegler-og-afhaengigheder`): Holder nøgler ude af kode, logs og Git og kontrollerer nye pakker, før de tilføjes.
- **Design og tilgængelighed** (`harness-design-og-tilgaengelighed`): Bygger brugerfladen efter godkendte designreferencer og afprøver tilgængelighed med både værktøjer og hænder.
- **Kodestil og vedligeholdelse** (`harness-kodestil`): Holder koden læsbar for andre med klare navne, enkle funktioner og kommentarer, der forklarer hvorfor.
- **Afprøvning og fejlretning** (`harness-afproevning-og-fejlretning`): Viser med faktisk afprøvning, at en ændring virker, og rapporterer præcist, hvor langt afprøvningen er nået.
- **Git og samarbejde** (`harness-git-og-samarbejde`): Skelner mellem gem, checkpoint, push, pull request og udgivelse og lader brugeren styre historikken.
- **Sikkerhedsgennemgang** (`harness-sikkerhedsgennemgang`): Gennemgår adgang, input, hemmeligheder og dataadskillelse og registrerer konkrete fund før drift.
- **Udgivelse og gendannelse** (`harness-udgivelse-og-gendannelse`): Gennemgår version, miljø, data og godkendelser før udgivelse og afprøver den rigtige adresse bagefter.
- **Overdragelse og drift** (`harness-overdragelse-og-drift`): Dokumenterer opstart, drift, ejerskab, opdateringer og gendannelse, så andre kan overtage.

Integrationer, der kan vælges til i Aura-appen: Adresser, CVR.

Instruktionerne er vejledning til kodeagenten. De er ikke adgangskontrol, en sikkerhedsgodkendelse eller en vurdering efter databeskyttelsesreglerne.
