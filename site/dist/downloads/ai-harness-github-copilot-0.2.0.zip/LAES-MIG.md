# AI Harness 0.2.0 til GitHub Copilot

Pakken giver GitHub Copilot AI Harness' fælles grundregler og 12 skills til arbejdet fra idé til drift. Filerne er på dansk og kan læses og tilpasses. Pakken indeholder ingen model, nøgle eller abonnement, og intet installeres eller køres automatisk.

Status: Efter værktøjets dokumentation. VS Code læser AGENTS.md i roden som standard; AGENTS.md i undermapper kræver en indstilling. Copilot CLI læser også CLAUDE.md og GEMINI.md, så reglerne kan optræde flere gange, hvis projektet har dem. Ændringer kræver en ny session i CLI.

## Indhold

Mappen `projekt` indeholder filerne, som de skal ligge i dit projekts øverste mappe:

- `AGENTS.md`
- `.github/skills/harness-ide-og-afgraensning/SKILL.md`
- `.github/skills/harness-eksisterende-projekt/SKILL.md`
- `.github/skills/harness-arkitektur-og-teknologi/SKILL.md`
- `.github/skills/harness-arkitektur-og-teknologi/references/offentlig-infrastruktur.md`
- `.github/skills/harness-data-og-leverandoerer/SKILL.md`
- `.github/skills/harness-data-og-leverandoerer/references/dataoversigt.md`
- `.github/skills/harness-data-og-leverandoerer/references/offentlige-krav.md`
- `.github/skills/harness-noegler-og-afhaengigheder/SKILL.md`
- `.github/skills/harness-design-og-tilgaengelighed/SKILL.md`
- `.github/skills/harness-design-og-tilgaengelighed/references/tilgaengelighed.md`
- `.github/skills/harness-kodestil/SKILL.md`
- `.github/skills/harness-afproevning-og-fejlretning/SKILL.md`
- `.github/skills/harness-git-og-samarbejde/SKILL.md`
- `.github/skills/harness-sikkerhedsgennemgang/SKILL.md`
- `.github/skills/harness-sikkerhedsgennemgang/references/tjekliste.md`
- `.github/skills/harness-udgivelse-og-gendannelse/SKILL.md`
- `.github/skills/harness-udgivelse-og-gendannelse/references/udgivelsestjekliste.md`
- `.github/skills/harness-overdragelse-og-drift/SKILL.md`
- `.github/skills/harness-overdragelse-og-drift/references/driftsvejledning.md`
- `.gitignore`
- `.harness/LAES-MIG.md`
- `.harness/installation.json`

Skillsene er beskrevet i `.github/skills/`. Læs om hver skill på webguidens side om skills eller i `.harness/LAES-MIG.md`.

## Tre måder at installere

### 1. Med AI Harness-appen

Vælg "Brug Harness i mit kodeværktøj", vælg GitHub Copilot og din projektmappe. Appen viser de præcise ændringer, før noget skrives, og kan fjerne installationen igen.

### 2. Bed din egen kodeagent om det

Åbn dit projekt i GitHub Copilot, og skriv:

> Jeg har pakket AI Harness 0.2.0 ud i mappen <STI TIL DEN UDPAKKEDE MAPPE>. Læs LAES-MIG.md i den mappe, og installer filerne fra undermappen projekt i dette projekt efter afsnittet "Til kodeagenten". Overskriv ingen eksisterende filer. Vis mig alle ændringer, før du skriver, og lav ingen commit.

### 3. Manuelt

1. Pak ZIP-filen ud i en separat mappe, ikke oven i dit projekt.
2. Mapper, der begynder med punktum, er skjulte. På Mac vises de med Cmd+Shift+punktum i Finder. På Windows slås skjulte elementer til under Vis i Stifinder.
3. Kopiér de skjulte mapper fra `projekt` til dit projekts øverste mappe. Findes en skill med samme navn allerede, så stop og sammenlign.
4. `AGENTS.md`, `.gitignore`: Hvis filen ikke findes i dit projekt, så kopiér den. Hvis den findes, så overskriv den ikke. Kopiér i stedet afsnittet fra markøren `ai-harness:start` til `ai-harness:slut`, og indsæt det nederst i din egen fil.
5. Kopiér `.harness/installation.json` med. Den gør det muligt senere at opdatere eller fjerne AI Harness uden at røre dine egne ændringer.

## Kontrollér, at det virker

I VS Code: kør Chat: Open Customizations, eller skriv /skills i chatten. I Copilot CLI: /skills list og /instructions. Brugte instruktioner vises under References i svaret.

Start en ny samtale, og skriv:

> Hvilke projektinstruktioner og skills fra AI Harness har du adgang til? Hvad er kontrolordet i AI Harness-profilen? Ændr ingen filer.

Forvent kontrolordet FÆLLES-GRUNDLAG-02 og en liste med skills, der begynder med harness-. Et korrekt svar viser, at filerne kan læses. Det viser ikke, at agenten følger dem i praksis.

## Opdatering og fjernelse

Installér en ny version på samme måde. Appen og scripts/harness.cjs opdaterer kun filer, der er uændrede siden installationen, og viser konflikter for resten. Ved manuel opdatering: sammenlign med dine filer, og bevar dine egne ændringer.

## Til kodeagenten

Følg disse regler, når du installerer pakken for brugeren:

1. Vis brugeren listen over filer, du vil oprette eller ændre, og vent på et ja.
2. Kopiér hver fil fra `projekt/` til samme relative sti i projektet. Opret manglende mapper.
3. Findes filen allerede med præcis samme indhold, så gør intet.
4. For `AGENTS.md`, `.gitignore`: Findes filen, så overskriv den ikke. Tilføj afsnittet mellem `ai-harness:start` og `ai-harness:slut` nederst med en tom linje foran. Findes afsnittet allerede, så spørg brugeren, før du erstatter det.
5. Findes en anden fil på en af stierne, eller en skillmappe med samme navn, så stop og spørg brugeren.
6. Rør ingen andre filer. Kør ingen scripts. Lav ingen commit, push eller branch.
7. Vis til sidst `git status` eller en liste over ændrede filer.

## Begrænsninger og kilder

Instruktionerne er vejledning til kodeagenten, ikke en sandbox, adgangskontrol eller garanti mod datalæk. `.gitignore` påvirker ikke filer, der allerede er sporet i Git. Filplaceringen er kontrolleret mod værktøjets dokumentation 2026-09-29. Modellers adfærd er ikke certificeret.

- GitHub om instruktioner: https://docs.github.com/en/copilot/reference/custom-instructions-support
- GitHub om skills i Copilot CLI: https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-skills
- VS Code om skills: https://code.visualstudio.com/docs/agent-customization/agent-skills
